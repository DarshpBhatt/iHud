function forPingTimer(){
 var lock =  window.navigator.requestWakeLock('screen');
 //set timeout or until the timer expires
}

 //test speed
//function that processes on load
function speed(){
//get user lat and long
function dgstoradians(dgs){

    return dgs * Math.PI / 180;
}


   

//var myVar = setInterval(currPosition,6000);
var latAr = [];
var longAr = [];
var i=0;
var y=1;
function onSuccess(position){
       // alert('Latitude: '          + position.coords.latitude          + '\n' +
           //   'Longitude: '         + position.coords.longitude         + '\n' +
             // 'Altitude: '          + position.coords.altitude          + '\n' +
             // 'Accuracy: '          + position.coords.accuracy          + '\n' +
              //'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
              //'Heading: '           + position.coords.heading           + '\n' +
            //  'Speed: '             + position.coords.speed             + '\n' +
            //  'Timestamp: '         + position.timestamp                + '\n');
       //document.getElementById("latitude").innerHTML = position.coords.latitude;
      //document.getElementById("longitude").innerHTML = position.coords.longitude;


   }
   function currPosition(position){
   latAr.push(position.coords.latitude);
longAr.push(position.coords.longitude);

   	

   //find distance travelled every 1 seconds
latAr.push(position.coords.latitude);
longAr.push(position.coords.longitude);

    //prior position
var lat1 = latAr[i];
var long1 = longAr[i];
//post position of 5 seconds
var lat2 = latAr[y];
var long2 = longAr[y];
var earthRadius = 6371;

  var dLat = dgstoradians(lat2-lat1);
  var dLon = dgstoradians(long2-long1);

lat1 = dgstoradians(lat1);
lat2 = dgstoradians(lat2);

var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  
  var kmtom = (earthRadius * c) * 1000;

var select = document.getElementById("speedUnit");
var unitSelected = select.options[select.selectedIndex].value;

if(unitSelected == "1")
{
	var kmph = ((kmtom * 3.6).toFixed(0));
	document.getElementById("speed").innerHTML = kmph +  "<br>";
    document.getElementById("unit").innerHTML = "km/h";
}
if(unitSelected == "2")
{
	var mph = ((kmtom * 2.237).toFixed(0));
	document.getElementById("speed").innerHTML = mph +  "<br>";
    document.getElementById("unit").innerHTML = "m/h";
}

//
i++;
y++;
}//end of currposition
setInterval(function(){ navigator.geolocation.getCurrentPosition(currPosition); }, 1000);
 navigator.geolocation.getCurrentPosition(onSuccess);


}//end of load func

function toRad(Value) {
    /** Converts numeric degrees to radians */
    return Value * Math.PI / 180;
}
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
} 

